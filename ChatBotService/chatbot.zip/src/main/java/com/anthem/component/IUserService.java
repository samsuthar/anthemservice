package com.anthem.component;

import com.anthem.User;

public interface IUserService {
  public User getUserDetails(Integer id);
}
