package com.anthem.component;

import org.springframework.stereotype.Component;

import com.anthem.User;

@Component
public class UserService implements IUserService {
	public User getUserDetails(Integer id) {
		User user = new User();
		user.setId(id);
		user.setName("Sam Suthar");
		return user;
	}
}
